//Verilog HDL for "AMP", "clk" "behavioral"


module clk (  clk);
output clk;
reg clk;
initial clk=0;
always #5000 clk = ~clk;


endmodule

